

<?php $__env->startSection('title','Nueva Orden'); ?>

<?php $__env->startSection('content'); ?>

<div class="card shadow">

    <div class="card-header bg-success text-white">
        <h3 class="mb-0">
            Nueva Orden de Servicio
        </h3>
    </div>

    <div class="card-body">

        <form action="<?php echo e(route('ordenes.store')); ?>" method="POST">

            <?php echo csrf_field(); ?>

            <div class="mb-3">
                <label class="form-label">Cliente</label>

                <select name="cliente_id" class="form-select">

                    <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <option value="<?php echo e($cliente->id_cliente); ?>">
                        <?php echo e($cliente->nombre); ?> <?php echo e($cliente->apellido); ?>

                    </option>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </select>
            </div>

            <div class="mb-3">
                <label class="form-label">Usuario</label>

                <select name="usuario_id" class="form-select">

                    <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <option value="<?php echo e($usuario->id_usuario); ?>">
                        <?php echo e($usuario->username); ?>

                    </option>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </select>
            </div>

            <div class="mb-3">
                <label class="form-label">Código Orden</label>

                <input
                    type="text"
                    name="codigo_orden"
                    class="form-control"
                    required>
            </div>

            <div class="mb-3">
                <label class="form-label">Descripción</label>

                <textarea
                    name="descripcion"
                    rows="4"
                    class="form-control"
                    required></textarea>
            </div>

            <div class="mb-3">
                <label class="form-label">Tipo Servicio</label>

                <input
                    type="text"
                    name="tipo_servicio"
                    class="form-control"
                    required>
            </div>

            <div class="mb-3">
                <label class="form-label">Prioridad</label>

                <select
                    name="prioridad"
                    class="form-select">

                    <option value="Baja">Baja</option>
                    <option value="Media">Media</option>
                    <option value="Alta">Alta</option>
                    <option value="Urgente">Urgente</option>

                </select>

            </div>

            <button
                type="submit"
                class="btn btn-success">

                <i class="bi bi-save"></i>
                Guardar Orden

            </button>

            <a href="<?php echo e(route('ordenes.index')); ?>"
               class="btn btn-secondary">

                Volver

            </a>

        </form>

    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ander\OneDrive\Escritorio\Antonio Jose Camacho\Sementre 2\Programacion III\CRUD ordenes de trabajo\resources\views/ordenes/create.blade.php ENDPATH**/ ?>