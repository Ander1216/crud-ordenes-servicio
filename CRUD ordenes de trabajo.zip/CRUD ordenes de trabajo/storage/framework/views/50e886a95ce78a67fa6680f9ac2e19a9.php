<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title'); ?></title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <link rel="stylesheet"
    href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">

    <div class="container">

        <span class="navbar-brand">
            Sistema de Órdenes de Servicio
        </span>

    </div>

</nav>

<div class="container mt-4">

    <?php echo $__env->yieldContent('content'); ?>

</div>

<footer class="text-center mt-5 mb-3 text-muted">

    Programación III - CRUD Órdenes de Servicio

</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html><?php /**PATH C:\Users\ander\OneDrive\Escritorio\Antonio Jose Camacho\Sementre 2\Programacion III\CRUD ordenes de trabajo\resources\views/layouts/app.blade.php ENDPATH**/ ?>