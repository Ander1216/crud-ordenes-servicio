

<?php $__env->startSection('title','Listado de Órdenes'); ?>

<?php $__env->startSection('content'); ?>

<h1 class="mb-4">
    Gestión de Órdenes
</h1>

<?php if(session('success')): ?>

<div class="alert alert-success alert-dismissible fade show" role="alert">

    <?php echo e(session('success')); ?>


    <button
        type="button"
        class="btn-close"
        data-bs-dismiss="alert">
    </button>

</div>

<?php endif; ?>

<a href="<?php echo e(route('ordenes.create')); ?>"
   class="btn btn-success mb-3">

    <i class="bi bi-plus-circle"></i>

    Nueva Orden

</a>

<table class="table table-bordered table-striped table-hover">

    <thead class="table-dark">

    <tr>
        <th>Cliente</th>
        <th>Usuario</th>
        <th>Código</th>
        <th>Descripción</th>
        <th>Tipo Servicio</th>
        <th>Prioridad</th>
        <th>Estado</th>
        <th>Fecha Cierre</th>
        <th>Fecha Creación</th>
        <th>Acción</th>
    </tr>

    </thead>

    <tbody>

    <?php $__currentLoopData = $ordenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orden): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <tr>

        <td><?php echo e($orden->cliente->nombre); ?> <?php echo e($orden->cliente->apellido); ?></td>
        <td><?php echo e($orden->usuario->username); ?></td>
        <td><?php echo e($orden->codigo_orden); ?></td>
        <td><?php echo e($orden->descripcion); ?></td>
        <td><?php echo e($orden->tipo_servicio); ?></td>
        <td><?php echo e($orden->prioridad); ?></td>
        <td><?php echo e($orden->estado); ?></td>
        <td><?php echo e($orden->fecha_cierre_estimada); ?></td>
        <td><?php echo e($orden->created_at); ?></td>

        <td>

            <a href="<?php echo e(route('ordenes.edit',$orden->id)); ?>"
               class="btn btn-primary btn-sm">

                <i class="bi bi-pencil-square"></i>

                Editar

            </a>

        </td>

    </tr>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </tbody>

</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ander\OneDrive\Escritorio\Antonio Jose Camacho\Sementre 2\Programacion III\CRUD ordenes de trabajo\resources\views/ordenes/index.blade.php ENDPATH**/ ?>