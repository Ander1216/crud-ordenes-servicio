

<?php $__env->startSection('title','Editar Orden'); ?>

<?php $__env->startSection('content'); ?>

<div class="card shadow">

    <div class="card-header bg-warning">
        <h3 class="mb-0">
            Editar Orden de Servicio
        </h3>
    </div>

    <div class="card-body">

        <form
            action="<?php echo e(route('ordenes.update',$orden->id)); ?>"
            method="POST">

            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="mb-3">
                <label class="form-label">Cliente</label>

                <input
                    type="text"
                    class="form-control"
                    value="<?php echo e($orden->cliente->nombre); ?> <?php echo e($orden->cliente->apellido); ?>"
                    readonly>
            </div>

            <div class="mb-3">
                <label class="form-label">Usuario</label>

                <input
                    type="text"
                    class="form-control"
                    value="<?php echo e($orden->usuario->username); ?>"
                    readonly>
            </div>

            <div class="mb-3">
                <label class="form-label">Código Orden</label>

                <input
                    type="text"
                    class="form-control"
                    value="<?php echo e($orden->codigo_orden); ?>"
                    readonly>
            </div>

            <div class="mb-3">
                <label class="form-label">Descripción</label>

                <textarea
                    class="form-control"
                    readonly><?php echo e($orden->descripcion); ?></textarea>
            </div>

            <div class="mb-3">
                <label class="form-label">Tipo Servicio</label>

                <input
                    type="text"
                    name="tipo_servicio"
                    value="<?php echo e($orden->tipo_servicio); ?>"
                    class="form-control">
            </div>

            <div class="mb-3">
                <label class="form-label">Prioridad</label>

                <select
                    name="prioridad"
                    class="form-select">

                    <option value="Baja"
                    <?php echo e($orden->prioridad=='Baja' ? 'selected' : ''); ?>>
                    Baja
                    </option>

                    <option value="Media"
                    <?php echo e($orden->prioridad=='Media' ? 'selected' : ''); ?>>
                    Media
                    </option>

                    <option value="Alta"
                    <?php echo e($orden->prioridad=='Alta' ? 'selected' : ''); ?>>
                    Alta
                    </option>

                    <option value="Urgente"
                    <?php echo e($orden->prioridad=='Urgente' ? 'selected' : ''); ?>>
                    Urgente
                    </option>

                </select>
            </div>

            <div class="mb-3">
                <label class="form-label">Estado</label>

                <select
                    name="estado"
                    class="form-select">

                    <option value="Pendiente"
                    <?php echo e($orden->estado=='Pendiente' ? 'selected' : ''); ?>>
                    Pendiente
                    </option>

                    <option value="En Proceso"
                    <?php echo e($orden->estado=='En Proceso' ? 'selected' : ''); ?>>
                    En Proceso
                    </option>

                    <option value="Cerrada"
                    <?php echo e($orden->estado=='Cerrada' ? 'selected' : ''); ?>>
                    Cerrada
                    </option>

                    <option value="Cancelada"
                    <?php echo e($orden->estado=='Cancelada' ? 'selected' : ''); ?>>
                    Cancelada
                    </option>

                </select>
            </div>

            <div class="mb-3">
                <label class="form-label">
                    Fecha Cierre Estimada
                </label>

                <input
                    type="date"
                    name="fecha_cierre_estimada"
                    value="<?php echo e($orden->fecha_cierre_estimada); ?>"
                    class="form-control">
            </div>

            <button
                type="submit"
                class="btn btn-warning">

                <i class="bi bi-pencil-square"></i>
                Actualizar

            </button>

            <a href="<?php echo e(route('ordenes.index')); ?>"
               class="btn btn-secondary">

                Volver

            </a>

        </form>

    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ander\OneDrive\Escritorio\Antonio Jose Camacho\Sementre 2\Programacion III\CRUD ordenes de trabajo\resources\views/ordenes/edit.blade.php ENDPATH**/ ?>